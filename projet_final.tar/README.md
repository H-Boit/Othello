# Othello
Jeux d'othello + bot 


Idées IA Séance 3 :

Utiliser un système de récompenses pour chaque coup joué lors de la descente de notre arbre de coup :
  - Chaque case a une pondération spécifique qui rapporte ou fait perdre des points
  - Plus on restreint l'adversaire plus on gagne des points


DOC :

- Serveur du prof : binome1 192.168.130.17 1
